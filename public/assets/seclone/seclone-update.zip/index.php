<?php
if ( ! defined( 'ABSPATH' ) ) {
    exit; // Exit if accessed directly
}

/**
 * The main template file
 * Update FINAL:
 * - Hero Slider HTML FIXED
 * - Solutions Slider SAFE
 * - News Card with SPINNING GREEN BORDER on hover
 */

get_header(); 

// --- LOGIKA BAHASA ---
$lang = get_bloginfo('language'); 
$is_indo = ( strpos($lang, 'id') !== false );

// Judul Section
$sec_title = $is_indo ? 'Jelajahi Solusi Kami' : 'Explore Our Solutions';
$sec_desc  = $is_indo 
    ? 'Kami menyediakan berbagai layanan teknis integrasi kelistrikan dan manufaktur.' 
    : 'We provide various technical services for electrical integration and manufacturing needs.';

// Label Tombol
$btn_label = $is_indo ? 'Selengkapnya' : 'Learn More';

/* === FUNCTION: Ambil gambar pertama dari konten (fallback thumbnail) === */
function bcp_get_first_image_from_content($post_id) {
    $post = get_post($post_id);
    if (!$post) return false;

    preg_match('/<img.+src=[\'"]([^\'"]+)[\'"].*>/i', $post->post_content, $matches);
    return $matches[1] ?? false;
}
?>

<!-- ================= HERO SLIDER (SWIPER) ================= -->
<div class="swiper hero-slider">

    <div class="swiper-wrapper">

        <?php 
        for ( $i = 1; $i <= 3; $i++ ) {

            $img = get_theme_mod( "hero_slide_image_$i" );
            if ( empty( $img ) ) {
                $img = 'https://images.unsplash.com/photo-1497366216548-37526070297c?auto=format&fit=crop&w=1600&q=80';
            }

            $title    = get_theme_mod( "hero_slide_title_$i", "Partner Digital Anda" );
            $desc     = get_theme_mod( "hero_slide_desc_$i", "Solusi integrasi terbaik." );
            $btn_text = get_theme_mod( "hero_slide_btn_text_$i", "Learn More" );
            $btn_url  = get_theme_mod( "hero_slide_btn_url_$i", "#" );
        ?>
            <div class="swiper-slide"
                 style="background-image:url('<?php echo esc_url($img); ?>');">

                <div class="overlay"></div>

                <div class="container slide-content">
                    <h1><?php echo wp_kses_post( $title ); ?></h1>

                    <div class="hero-desc">
                        <?php echo wp_kses_post( $desc ); ?>
                    </div>

                    <?php if($btn_text) : ?>
                        <a href="<?php echo esc_url( $btn_url ); ?>" class="btn-se">
                            <?php echo esc_html( $btn_text ); ?>
                        </a>
                    <?php endif; ?>
                </div>
            </div>
        <?php } ?>

    </div>

    <div class="swiper-pagination"></div>
    <div class="swiper-button-prev"></div>
    <div class="swiper-button-next"></div>

</div>
<!-- ================= END HERO SLIDER ================= -->

<!-- ================= SOLUTIONS SECTION ================= -->
<section class="solutions-section">
    <div class="container">

        <div style="display:flex; justify-content:space-between; align-items:flex-end; margin-bottom:30px;">
            <div style="max-width:700px;">
                <h2 style="font-size:2rem; margin-bottom:10px;">
                    <?php echo esc_html($sec_title); ?>
                </h2>
                <p style="color:#666;">
                    <?php echo esc_html($sec_desc); ?>
                </p>
            </div>

            <div class="slider-nav-btns mobile-hide">
                <button class="slider-btn" onclick="document.querySelector('.solutions-slider').scrollBy({left:-360,behavior:'smooth'})">&larr;</button>
                <button class="slider-btn" onclick="document.querySelector('.solutions-slider').scrollBy({left:360,behavior:'smooth'})">&rarr;</button>
            </div>
        </div>

        <div class="solutions-slider">
        <?php for ( $k = 1; $k <= 6; $k++ ) : 

            $s_img      = get_theme_mod("sol_img_$k");
            $s_cat_id   = get_theme_mod("sol_cat_id_$k", "Kategori $k");
            $s_cat_en   = get_theme_mod("sol_cat_en_$k", "Category $k");
            $s_title_id = get_theme_mod("sol_title_id_$k", "Judul Solusi $k");
            $s_title_en = get_theme_mod("sol_title_en_$k", "Solution Title $k");
            $s_desc_id  = get_theme_mod("sol_desc_id_$k", "Deskripsi singkat layanan.");
            $s_desc_en  = get_theme_mod("sol_desc_en_$k", "Short service description.");
            $s_link     = get_theme_mod("sol_link_$k", '#');

            $show_cat   = $is_indo ? $s_cat_id : $s_cat_en;
            $show_title = $is_indo ? $s_title_id : $s_title_en;
            $show_desc  = $is_indo ? $s_desc_id : $s_desc_en;

            if(empty($s_img)) {
                $s_img = 'https://via.placeholder.com/600x400/eeeeee/cccccc?text=No+Image';
            }
        ?>
            <div class="solution-card">
                <img src="<?php echo esc_url($s_img); ?>" 
                     alt="<?php echo esc_attr($show_title); ?>" 
                     class="solution-img">

                <div class="solution-content">
                    <h4 style="color:var(--se-green); font-size:0.8rem; font-weight:800; margin-bottom:10px;">
                        <?php echo esc_html($show_cat); ?>
                    </h4>

                    <h3 style="margin-bottom:15px;">
                        <a href="<?php echo esc_url($s_link); ?>" style="color:inherit; text-decoration:none;">
                            <?php echo esc_html($show_title); ?>
                        </a>
                    </h3>

                    <p style="font-size:0.9rem; color:#666; margin-bottom:25px; line-height:1.6;">
                        <?php echo esc_html($show_desc); ?>
                    </p>

                    <a href="<?php echo esc_url($s_link); ?>" style="font-weight:bold; color:var(--se-dark);">
                        <?php echo esc_html($btn_label); ?> →
                    </a>
                </div>
            </div>
        <?php endfor; ?>
        </div>

    </div>
</section>
<!-- ================= END SOLUTIONS ================= -->


<!-- ================= NEWS & LATEST UPDATES ================= -->
<section class="container" style="padding:60px 20px;">
    <h2 style="margin-bottom:30px; font-size:2rem;">
        <?php echo $is_indo ? 'Berita & ' : 'News & '; ?>
        <strong style="color:var(--se-green);">
            <?php echo $is_indo ? 'Update Terbaru' : 'Latest Updates'; ?>
        </strong>
    </h2>

    <div class="news-grid">
    <?php
    $home_news = new WP_Query([
        'post_type'      => 'post',
        'posts_per_page' => 2,
        'post_status'    => 'publish',
        'orderby'        => 'date',
        'order'          => 'DESC',
    ]);

    if ($home_news->have_posts()) :
        while ($home_news->have_posts()) : $home_news->the_post();

            if (has_post_thumbnail()) {
                $thumb_url = get_the_post_thumbnail_url(get_the_ID(), 'medium');
            } else {
                $thumb_url = bcp_get_first_image_from_content(get_the_ID());
            }
    ?>
        <article class="news-card news-card--spin">

            <?php if ($thumb_url) : ?>
                <div class="news-thumb">
                    <img src="<?php echo esc_url($thumb_url); ?>" alt="<?php the_title_attribute(); ?>">
                </div>
            <?php endif; ?>

            <h3><?php the_title(); ?></h3>

            <p class="news-excerpt">
                <?php echo wp_trim_words(get_the_excerpt(), 22); ?>
            </p>

            <a href="<?php the_permalink(); ?>" class="read-more">
                <?php echo $is_indo ? 'Baca Selengkapnya' : 'Read More'; ?> →
            </a>

        </article>
    <?php endwhile; wp_reset_postdata(); else : ?>
        <p style="color:#999;">
            <?php echo $is_indo ? 'Belum ada berita.' : 'No news available.'; ?>
        </p>
    <?php endif; ?>
    </div>
</section>
<!-- ================= END NEWS ================= -->

<?php get_footer(); ?>
